// header

// window.onscroll = function () { myFunction() };

// var navbar = document.getElementById("navbar");
// var sticky = navbar.offsetTop;

// function myFunction() {
//     if (window.pageYOffset >= sticky) {
//         navbar.classList.add("sticky")
//     } else {
//         navbar.classList.remove("sticky");
//     }
// }

function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function () {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
            dropdownContent.style.display = "none";
        } else {
            dropdownContent.style.display = "block";
        }
    });
}

// IMG

let slideIndex = 0;
showSlides();

function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    let dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) { slideIndex = 1 }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
    setTimeout(showSlides, 2000); // Change image every 2 seconds
}

const getflashsale=()=>{
    fetch('http://localhost:3111/promotion/flashsale',{method:'GET',mode:'cors'})
    .then((res)=>res.json())
    .then((data)=>{
        data.map((element)=>{

        let createIMG = document.createElement("IMG")
        let createLabel = document.createElement("label")
        createLabel.innerText =  element.product_name
        let createA = document.createElement('a')
        let imgDiv = document.getElementById('flashsale-carousel')

        createIMG.setAttribute('src',element.image)
        createIMG.setAttribute('draggable',false)
        // let createDiv = document.createElement('div')
        createIMG.classList.add('flashIMG')
        createLabel.classList.add('Labelflash')
        // createDiv.classList.add('flashDiv')
        // createA.setAttribute('href','/picview.html?id='+element.pid)
        imgDiv.appendChild(createIMG)
        createIMG.appendChild(createA)
        createIMG.appendChild(createLabel)
    
        // console.log(createLabel.innerText);
        })
    }).then(data =>{
        carouselOn("flashsale","img")
    })
    
}

const getLod=()=>{
    fetch('http://localhost:3111/promotion/lod',{method:'GET',mode:'cors'})
    .then((res)=>res.json())
    .then((data)=>{
        data.map((element)=>{
        let createIMG = document.createElement("IMG")
        
        let createA = document.createElement('a')
        let imgDiv = document.getElementById('lod-carousel')
        createIMG.setAttribute('draggable',false)
        createIMG.setAttribute('src',element.image)
        createIMG.classList.add('flashIMG')
        // createA.setAttribute('href','/picview.html?id='+element.pid)
        imgDiv.appendChild(createIMG)
        createIMG.appendChild(createA)
        // createIMG.appendChild(create)
        })
    })
    
    .then(data =>{
        carouselOn("lod","img")
    })
}

const getFood=()=>{
    fetch('http://localhost:3111/promotion/food',{method:'GET',mode:'cors'})
    .then((res)=>res.json())
    .then((data)=>{
        data.map((element)=>{
        let createIMG = document.createElement("IMG")
        let createA = document.createElement('a')
        let imgDiv = document.getElementById('food')
        createIMG.setAttribute('src',element.image)
        createIMG.classList.add('flashIMG')
        // createA.setAttribute('href','/picview.html?id='+element.pid)
        imgDiv.appendChild(createA)
        createA.appendChild(createIMG)
        })
    })
}
const getBeauty=()=>{
    fetch('http://localhost:3111/promotion/beauty',{method:'GET',mode:'cors'})
    .then((res)=>res.json())
    .then((data)=>{
        data.map((element)=>{
        let createIMG = document.createElement("IMG")
        let createA = document.createElement('a')
        let imgDiv = document.getElementById('beauty')
        createIMG.setAttribute('src',element.image)
        createIMG.classList.add('flashIMG')
        // createA.setAttribute('href','/picview.html?id='+element.pid)
        imgDiv.appendChild(createA)
        createA.appendChild(createIMG)
        })
    })
}
const getSuper=()=>{
    fetch('http://localhost:3111/promotion/super',{method:'GET',mode:'cors'})
    .then((res)=>res.json())
    .then((data)=>{
        data.map((element)=>{
        let createIMG = document.createElement("IMG")
        let createA = document.createElement('a')
        let imgDiv = document.getElementById('super')
        createIMG.setAttribute('src',element.image)
        createIMG.classList.add('flashIMG')
        // createA.setAttribute('href','/picview.html?id='+element.pid)
        imgDiv.appendChild(createA)
        createA.appendChild(createIMG)
        })
    })
}
const getHousehold=()=>{
    fetch('http://localhost:3111/promotion/household',{method:'GET',mode:'cors'})
    .then((res)=>res.json())
    .then((data)=>{
        data.map((element)=>{
        let createIMG = document.createElement("IMG")
        let createA = document.createElement('a')
        let imgDiv = document.getElementById('household')
        createIMG.setAttribute('src',element.image)
        createIMG.classList.add('flashIMG')
        // createA.setAttribute('href','/picview.html?id='+element.pid)
        imgDiv.appendChild(createA)
        createA.appendChild(createIMG)
        })
    })
}
const getFashion=()=>{
    fetch('http://localhost:3111/promotion/fashion',{method:'GET',mode:'cors'})
    .then((res)=>res.json())
    .then((data)=>{
        data.map((element)=>{
        let createIMG = document.createElement("IMG")
        let createA = document.createElement('a')
        let imgDiv = document.getElementById('fashion')
        createIMG.setAttribute('src',element.image)
        createIMG.classList.add('flashIMG')
        // createA.setAttribute('href','/picview.html?id='+element.pid)
        imgDiv.appendChild(createA)
        createA.appendChild(createIMG)
        })
    })
}
// slider




    getflashsale()
    getLod()
    getSuper()
    getFood()
    getFashion()
    getBeauty()
    getHousehold()
    carouselOn("promotion","img")


function carouselOn (id,type){
const carousel = document.querySelector(`#${id}-carousel`),
firstImg = carousel.querySelectorAll(type)[0],
arrowIcons = document.querySelectorAll(`#${id}-warpper i`);
console.log(firstImg.clientWidth);



let isDragStart = false, isDragging = false, prevPageX, prevScrollLeft, positionDiff;

const showHideIcons = () => {
    // showing and hiding prev/next icon according to carousel scroll left value
    let scrollWidth = carousel.scrollWidth - carousel.clientWidth; // getting max scrollable width
    arrowIcons[0].style.display = carousel.scrollLeft == 0 ? "none" : "block";
    arrowIcons[1].style.display = carousel.scrollLeft == scrollWidth ? "none" : "block";
}

arrowIcons.forEach(icon => {
    icon.addEventListener("click", () => {
        let firstImgWidth = firstImg.clientWidth + 14; // getting first img width & adding 14 margin value
        // if clicked icon is left, reduce width value from the carousel scroll left else add to it
        carousel.scrollLeft += icon.id == "left" ? -firstImgWidth : firstImgWidth;
        setTimeout(() => showHideIcons(), 60); // calling showHideIcons after 60ms
    });
});

const autoSlide = () => {
    // if there is no image left to scroll then return from here
    if(carousel.scrollLeft - (carousel.scrollWidth - carousel.clientWidth) > -1 || carousel.scrollLeft <= 0) return;

    positionDiff = Math.abs(positionDiff); // making positionDiff value to positive
    let firstImgWidth = firstImg.clientWidth + 14;
    // getting difference value that needs to add or reduce from carousel left to take middle img center
    let valDifference = firstImgWidth - positionDiff;

    if(carousel.scrollLeft > prevScrollLeft) { // if user is scrolling to the right
        return carousel.scrollLeft += positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
    }
    // if user is scrolling to the left
    carousel.scrollLeft -= positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
}

const dragStart = (e) => {
    // updatating global variables value on mouse down event
    isDragStart = true;
    prevPageX = e.pageX || e.touches[0].pageX;
    prevScrollLeft = carousel.scrollLeft;
}

const dragging = (e) => {
    // scrolling images/carousel to left according to mouse pointer
    if(!isDragStart) return;
    e.preventDefault();
    isDragging = true;
    carousel.classList.add("dragging");
    positionDiff = (e.pageX || e.touches[0].pageX) - prevPageX;
    carousel.scrollLeft = prevScrollLeft - positionDiff;
    showHideIcons();
}

const dragStop = () => {
    isDragStart = false;
    carousel.classList.remove("dragging");

    if(!isDragging) return;
    isDragging = false;
    autoSlide();
}

carousel.addEventListener("mousedown", dragStart);
carousel.addEventListener("touchstart", dragStart);

document.addEventListener("mousemove", dragging);
carousel.addEventListener("touchmove", dragging);

document.addEventListener("mouseup", dragStop);
carousel.addEventListener("touchend", dragStop);
}

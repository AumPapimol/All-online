const express = require("express");
const app = express();
const routerPromotion = require("./router/user")
const cors = require('cors')

app.use(cors())
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('./public'))

app.use("/promotion", routerPromotion)

app.listen(3111, () => { console.log("running on port 3111") })


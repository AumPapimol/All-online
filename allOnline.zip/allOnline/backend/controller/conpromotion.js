const db = require("../server/connection")


async function getflashsale (req, res) {
    const [flashsale] =await db.query('SELECT product_name,sell_price ,category,subcategory,stock,image FROM  products;');

    return res.json(flashsale)
}
async function getLod (req, res) {
    const [lod] = await db.query('SELECT product_name,sell_price ,category,subcategory,stock,image FROM  products;');
    console.log(lod);

    return res.json(lod)
}
async function getSuper (req, res) {
    const [lod] =await db.query('SELECT product_name,sell_price ,category,subcategory,stock,image FROM  products;');
    

    return res.json(lod)
}

async function getFood (req, res) {
    const [lod] =await db.query('SELECT product_name,sell_price ,category,subcategory,stock,image FROM  products;');
    

    return res.json(lod)
}
async function getBeauty (req, res) {
    const [lod] =await db.query('SELECT product_name,sell_price ,category,subcategory,stock,image FROM  products;');
    

    return res.json(lod)
}

async function getFashion (req, res) {
    const [lod] =await db.query('SELECT product_name,sell_price ,category,subcategory,stock,image FROM  products;');
    

    return res.json(lod)
}
async function getHousehold (req, res) {
    const [lod] =await db.query('SELECT product_name,sell_price ,category,subcategory,stock,image FROM  products;');
    

    return res.json(lod)
}
module.exports = {
    getflashsale,
    getLod,
    getSuper,
    getFood,
    getFashion,
    getHousehold,
    getBeauty
};
